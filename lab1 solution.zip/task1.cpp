#include<conio.h>
#include<iostream>
#include<time.h>
using namespace std;


int main()
{
	int a[40][40], b[40][    40], c[40][40];
	int x, y, i, j, m, n, num1, num2;

	srand(time(NULL)); //  the random number genrator

	cout << "\nPlease Enter the number of rows and columns for Matrix say X:\n\n";
	cin >> x >> y; // x denotes number rows in matrix X and y denotes number columns in matrix Y

	cout << "\n\nRandom elements for Matrix X :\n\n";
	for (i = 0; i < x; i++)
	{
		for (j = 0; j < y; j++)
		{
			num1 = (rand() % 10); // The function for random number generating


			a[i][j] = num1;
			cout << num1 << endl;
		}
		cout << "\n";
	}
	cout << "\n\nMatrix X :\n\n";
	for (i = 0; i < x; i++)
	{
		for (j = 0; j < y; j++)
		{
			cout << "\t" << a[i][j];
		}
		cout << "\n\n";
	}
	cout << "\n-----------------------------------------------------------\n";
	cout << "\nEnter the number of rows and columns for Matrix say Y:\n\n";
	cin >> m >> n;
	// m denotes number rows in matrix B
	// n denotes number columns in matrix B

	cout << "\nElemets for random matrix Y are \n\n";
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < n; j++)
		{
			num2 = (rand() % 10);
			b[i][j] = num2;
			cout << num2 << endl;

		}
		cout << "\n";
	}
	cout << "\n\nMatrix Y :\n\n";
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < n; j++)
		{
			cout << "\t" << b[i][j];
		}
		cout << "\n\n";
	}

	if (y == m)
	{
		for (i = 0; i < x; i++) // three nested loop for multiplication whic makes the time complexity of n^3
		{
			for (j = 0; j < n; j++)
			{
				c[i][j] = 0;

				for (int k = 0; k < m; k++)
				{
					c[i][j] = c[i][j] + a[i][k] * b[k][j];
				}
			}
		}
		cout
			<< "\n-----------------------------------------------------------\n";
		cout << "\n\nMultiplication of Matrix X and Matrix Y :\n\n";
		for (i = 0; i < x; i++)
		{
			for (j = 0; j < n; j++)
			{
				cout << "\t" << c[i][j]; // Just outputing the resultant results
			}
			cout << "\n\n";
		}
	}
	else
	{
		cout << "\n\nMultiplication is not possible";
	}
	getchar();
	getchar();

	return 0;
}